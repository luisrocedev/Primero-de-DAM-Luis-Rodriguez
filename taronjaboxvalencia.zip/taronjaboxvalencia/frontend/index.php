<?php include '../frontend/header.php'; ?>
<main>
</main>
<script src="script.js" defer></script>
<?php include '../frontend/footer.php'; ?>
<h2>Entradas de Blog</h2>
<div id="blog-posts"></div> <!-- Este es el contenedor donde se mostrarán las entradas -->
<!-- Vinculamos el archivo CSS para los estilos -->
<link rel="stylesheet" href="style.css">
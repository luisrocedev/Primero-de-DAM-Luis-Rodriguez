<header>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TaronjaBox</title>
    <link rel="stylesheet" href="style.css"> <!-- Enlace al archivo CSS -->

    <nav>
        <ul>
            <li><a href="index.php">Inicio</a></li>
            <li><a href="blog/index.php">Blog</a></li> <!-- Enlace al blog -->
            <li><a href="fisioterapia/index.php">Fisioterapia</a></li> <!-- Enlace al blog -->
            <li><a href="contacto/index.php">Contacto</a></li>
        </ul>
    </nav>
</header>
let vida = 100;
let municion = 10;

function actualizarHUD() {
    document.getElementById("vidaValor").textContent = vida;
    document.getElementById("municionValor").textContent = municion;
}
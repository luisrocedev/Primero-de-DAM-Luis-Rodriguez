<?php

class Database {
    private static $connection;

    public static function getConnection() {
        if (!self::$connection) {
            self::$connection = new PDO(
                'mysql:host=localhost;dbname=taronjabox;charset=utf8mb4',
                'taronjabox', // Usuario
                'taronjabox',     // Contraseña
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                ]
            );
        }
        return self::$connection;
    }
}

?>
<?php
require_once '../../config/database.php';

try {
    $db = Database::getConnection();
    echo "Conexión exitosa a la base de datos";
} catch (Exception $e) {
    echo "Error de conexión: " . $e->getMessage();
}
?>


<?php

require_once '../models/Entrenador.php';

class EntrenadoresController {
    public function obtenerTodos() {
        $entrenador = new Entrenador();
        return $entrenador->obtenerTodos();
    }
}

?>

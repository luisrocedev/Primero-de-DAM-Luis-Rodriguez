<?php
function getBaseURL() {
    // Adjust this to the correct base URL of your project
    return "http://localhost/GitHub/Primero-de-DAM-Luis-Rodriguez/TaronjaboxNew modulo";
}
?>

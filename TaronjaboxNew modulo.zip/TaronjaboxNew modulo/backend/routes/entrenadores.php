<?php

require_once '../controllers/EntrenadoresController.php';

header('Content-Type: application/json');

$controller = new EntrenadoresController();
echo json_encode($controller->obtenerTodos());

?>

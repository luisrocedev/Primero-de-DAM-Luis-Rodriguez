document.addEventListener('DOMContentLoaded', () => {
    fetch('../../backend/routes/entrenadores.php')
        .then(response => response.json())
        .then(data => {
            const container = document.getElementById('entrenadores');
            data.forEach(entrenador => {
                const div = document.createElement('div');
                div.classList.add('entrenador');
                div.innerHTML = `
                    <h2>${entrenador.nombre}</h2>
                    <p>${entrenador.especialidad}</p>
                    <p>${entrenador.descripcion}</p>
                    <img src="${entrenador.foto_url}" alt="${entrenador.nombre}">
                `;
                container.appendChild(div);
            });
        })
        .catch(error => console.error('Error al cargar entrenadores:', error));
});

<?php
require_once '../helpers/getBaseURL.php';
$apiURL = getBaseURL() . '/backend/routes/entrenadores.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <link rel="stylesheet" href="entrenador.css">
    <script defer src="entrenador.js"></script>
</head>
<body>
    <div class="entrenadores-container" id="entrenadores">
        <!-- Aquí se cargarán los entrenadores dinámicamente -->
    </div>
</body>
</html>

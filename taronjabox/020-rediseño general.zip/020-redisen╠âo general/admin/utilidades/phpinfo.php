<?php

	phpinfo();

?>

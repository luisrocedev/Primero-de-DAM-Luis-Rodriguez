<?php
	
	ini_set('display_errors', 1);					// Si hay error, dimelo
	ini_set('display_startup_errors', 1);		// Sacame los errores de arranque
	error_reporting(E_ALL);							// Sacame todo tipo de errores

?>

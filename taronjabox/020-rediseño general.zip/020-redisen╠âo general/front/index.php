<?php include "inc/errores.php"; ?>
<!doctype html>
<html>
	<head>
		<?php include "inc/cabeza.php"; ?>
	</head>
	<body>
		<?php include "modulos/cabecera/cabecera.php"; ?>
		<?php include "modulos/principal/principal.php"; ?>
		<?php include "modulos/piedepagina/piedepagina.php"; ?>
	</body>
</html>










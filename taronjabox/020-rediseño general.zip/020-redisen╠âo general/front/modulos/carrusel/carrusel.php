<section id="carrusel">
	<div class="contenedor">
		<div id="carrusel1" class="animado1">
			<article>1
				<button>Call to action</button>
				<p>Pequeño texto</p>
			</article>
			<article>2
				<button>Call to action</button>
				<p>Pequeño texto</p>
			</article>
			<article>3
				<button>Call to action</button>
				<p>Pequeño texto</p>
			</article>
			<article>4
				<button>Call to action</button>
				<p>Pequeño texto</p>
			</article>
			<article>5
				<button>Call to action</button>
				<p>Pequeño texto</p>
			</article>
			<article>6
				<button>Call to action</button>
				<p>Pequeño texto</p>
			</article>
			<article>7
				<button>Call to action</button>
				<p>Pequeño texto</p>
			</article>
			<article>8
				<button>Call to action</button>
				<p>Pequeño texto</p>
			</article>
		</div>
		<div id="botonera">
			<div class="punto"></div>
			<div class="punto"></div>
			<div class="punto"></div>
			<div class="punto"></div>
			<div class="punto"></div>
			<div class="punto"></div>
			<div class="punto"></div>
			<div class="punto"></div>
		</div>
		<div id="carrusel2" class="animado2">
			<article>
				<button>Call to action</button>
				<p>Pequeño texto</p>
			</article>
			<article>
				<button>Call to action</button>
				<p>Pequeño texto</p>
			</article>
			<article>
				<button>Call to action</button>
				<p>Pequeño texto</p>
			</article>
			<article>
				<button>Call to action</button>
				<p>Pequeño texto</p>
			</article>
			<article>
				<button>Call to action</button>
				<p>Pequeño texto</p>
			</article>
			<article>
				<button>Call to action</button>
				<p>Pequeño texto</p>
			</article>
			<article>
				<button>Call to action</button>
				<p>Pequeño texto</p>
			</article>
			<article>
				<button>Call to action</button>
				<p>Pequeño texto</p>
			</article>
		</div>
	</div>
</section>
	
	<script>
	<?php include "carrusel.js"?>
</script>
<style>
	<?php include "carrusel.css"?>
</style>

<section id="destacados">
	<template id="plantilladestacado">
		<article>
			<h3>Título</h3>
			<h4>Frase de marketing</h4>
			<button>Call to action 1</button>
			<button>Call to action 2</button>
		</article>
	</template>
</section>

<script>
	<?php include "destacados.js"?>
</script>
<style>
	<?php include "destacados.css"?>
</style>

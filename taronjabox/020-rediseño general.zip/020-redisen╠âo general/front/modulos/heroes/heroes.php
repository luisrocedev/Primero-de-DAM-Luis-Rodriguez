<section id="heroes">

	<template id="plantillaheroe">
		<article class="heroe">
			<h3>Nombre del producto</h3>
			<h4>Frase de marketing</h4>
			<button>Call to action 1</button>
			<button>Call to action 2</button>
		</article>
	</template>
	
</section>	
	<script>
	<?php include "heroes.js"?>
</script>
<style>
	<?php include "heroes.css"?>
</style>

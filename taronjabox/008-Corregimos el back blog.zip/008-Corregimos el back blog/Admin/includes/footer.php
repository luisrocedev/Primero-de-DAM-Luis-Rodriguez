<footer>
    <p>&copy; 2025 TaronjaBox. Todos los derechos reservados.</p>
</footer>
</body>
</html>

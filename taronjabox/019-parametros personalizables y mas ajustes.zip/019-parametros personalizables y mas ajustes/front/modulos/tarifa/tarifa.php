<section id="tarifas">
	<template id="plantillatarifa">
		<article>
			<h3>Título</h3>
			<h4>Frase de marketing</h4>
			<button>Call to action 1</button>
			<button>Call to action 2</button>
		</article>
	</template>
</section>

<script>
	<?php include "tarifa.js"?>
</script>
<style>
	<?php include "tarifa.css"?>
</style>

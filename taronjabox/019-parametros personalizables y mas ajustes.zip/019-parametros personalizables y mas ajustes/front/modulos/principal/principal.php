<main>
	
	<?php include "modulos/oferta/oferta.php" ?>
	<?php include "modulos/heroes/heroes.php" ?>
	<?php include "modulos/tarifa/tarifa.php" ?>
	<?php include "modulos/carrusel/carrusel.php" ?>
	<?php include "modulos/aviso_legal/aviso_legal" ?>
	
</main>

<section>
	<div class="contenedor">
		disclaimer.
	</div>
</section>

<section id="sobrenosotros">
	<template id="plantillasobrenosotros">
		<article>
			<h3>Sobre nosotros</h3>
			<h4>Prueba</h4>
			<button>Call to action 1</button>
			<button>Call to action 2</button>
		</article>
	</template>
</section>

<script>
	<?php include "sobrenosotros.js"?>
</script>
<style>
	<?php include "sobrenosotros.css"?>
</style>

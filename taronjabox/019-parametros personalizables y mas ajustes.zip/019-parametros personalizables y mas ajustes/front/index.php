<!doctype html>
<html>
	<head>
		<title>Taronja Box</title>
		<link rel="Stylesheet" href="estilo/general.css">
		<meta charset="utf-8">
	</head>
	<body>
		<?php include "modulos/header/header.php"; ?>
		<?php include "modulos/principal/principal.php"; ?>
		<?php include "modulos/piedepagina/piedepagina.php"; ?>
		<?php include "modulos/avisolegal/avisolegal.php"; ?>
	</body>
</html>
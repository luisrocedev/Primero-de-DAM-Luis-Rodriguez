<footer>
    <p>&copy; <?= date('Y'); ?> TaronjaBox Valencia. Todos los derechos reservados.</p>
</footer>
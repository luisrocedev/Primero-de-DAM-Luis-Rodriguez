<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Noticia</title>
    <link rel="stylesheet" href="../../../admin/assets/css/noticias-styles.css">
</head>

<body>
    <h1>Crear Noticia</h1>
    <form method="POST" action="?action=create">
        <label for="titulo">Título:</label>
        <input type="text" id="titulo" name="titulo" required>

        <label for="contenido">Contenido:</label>
        <textarea id="contenido" name="contenido" rows="5" required></textarea>

        <label for="imagen">URL de la Imagen (opcional):</label>
        <input type="text" id="imagen" name="imagen">

        <label for="fecha_evento">Fecha del Evento:</label>
        <input type="date" id="fecha_evento" name="fecha_evento">

        <button type="submit" class="btn">Crear Noticia</button>
    </form>
</body>

</html>
INSERT INTO `fichajes` (`Identificador`, `valor`, `jugadores_nombre`, `equipos_nombre`, `fechainicio`, `fechafinal`) VALUES (NULL, '10000000', '1', '1', '2024-10-16', '2025-10-15');

INSERT INTO `jornadas` (`Identificador`, `fecha`, `divisiones_nombre`) VALUES (NULL, '2024-10-18', '2');

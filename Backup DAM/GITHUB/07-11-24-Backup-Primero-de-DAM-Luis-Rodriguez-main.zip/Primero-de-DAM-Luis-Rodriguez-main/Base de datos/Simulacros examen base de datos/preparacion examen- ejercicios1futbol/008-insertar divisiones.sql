INSERT INTO `divisiones` (`Identificador`, `nombre`) VALUES (NULL, 'Primera');
INSERT INTO `divisiones` (`Identificador`, `nombre`) VALUES (NULL, 'Segunda');
INSERT INTO `divisiones` (`Identificador`, `nombre`) VALUES (NULL, 'Primera Federación');
INSERT INTO `divisiones` (`Identificador`, `nombre`) VALUES (NULL, 'Segunda Federación');



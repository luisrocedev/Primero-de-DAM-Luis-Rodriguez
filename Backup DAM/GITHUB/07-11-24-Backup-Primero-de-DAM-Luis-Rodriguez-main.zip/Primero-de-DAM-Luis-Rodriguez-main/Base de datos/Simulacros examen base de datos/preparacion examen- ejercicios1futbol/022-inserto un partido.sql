INSERT INTO `partidos` (`Identificador`, `visitante`, `local`, `jornada`, `horadeinicio`, `golesvisitante`, `goleslocal`) VALUES (NULL, '2', '1', '1', '21:00:00', '1', '3');

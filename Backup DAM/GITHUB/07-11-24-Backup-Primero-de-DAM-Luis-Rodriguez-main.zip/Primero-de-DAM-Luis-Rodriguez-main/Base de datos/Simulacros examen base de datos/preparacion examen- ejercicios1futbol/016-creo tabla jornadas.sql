CREATE TABLE `futbol`.`jornadas` (`Identificador` INT NOT NULL AUTO_INCREMENT , `fecha` DATE NOT NULL , `divisiones_nombre` INT NOT NULL , PRIMARY KEY (`Identificador`)) ENGINE = InnoDB;

CREATE TABLE `futbol`.`paises`
 (`identificador` INT(255) NOT NULL AUTO_INCREMENT ,
  `nombre` VARCHAR(255) NOT NULL ,
   PRIMARY KEY (`identificador`)) ENGINE = InnoDB;
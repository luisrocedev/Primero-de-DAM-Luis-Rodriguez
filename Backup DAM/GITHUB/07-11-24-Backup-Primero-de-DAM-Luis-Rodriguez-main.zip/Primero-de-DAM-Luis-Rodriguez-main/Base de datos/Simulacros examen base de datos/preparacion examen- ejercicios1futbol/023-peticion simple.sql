SELECT * FROM partidos;

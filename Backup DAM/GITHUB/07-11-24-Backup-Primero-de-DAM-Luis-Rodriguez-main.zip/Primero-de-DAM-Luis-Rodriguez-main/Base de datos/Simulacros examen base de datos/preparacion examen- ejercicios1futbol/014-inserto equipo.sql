INSERT INTO `equipos` (`Identificador`, `nombre`, `divisiones_nombre`) VALUES (NULL, 'Mislata Club de Futbol', '2');

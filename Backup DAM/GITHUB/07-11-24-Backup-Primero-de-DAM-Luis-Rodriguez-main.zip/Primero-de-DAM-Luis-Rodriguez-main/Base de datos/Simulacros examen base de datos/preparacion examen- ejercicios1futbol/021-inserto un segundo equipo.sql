INSERT INTO `equipos` (`Identificador`, `nombre`, `divisiones_nombre`) VALUES (NULL, 'Manises CF', '2');


INSERT INTO`tabla entrenadores` 
(`Nombre`, `Especialidad`, `Correo`, `Teléfono`, `Certificaciones`) 
VALUES
('Carlos Martínez', 'Entrenamiento Funcional', 'carlos.martinez@ejemplo.com', '5551234567', 'Certificación en CrossFit, Certificación en Entrenamiento Funcional'),
('María Gómez', 'Pilates', 'maria.gomez@ejemplo.com', '5552345678', 'Certificación en Pilates, Yoga Instructor Certificado'),
('Juan Pérez', 'Levantamiento de Pesas', 'juan.perez@ejemplo.com', '5553456789', 'Certificación en Levantamiento de Pesas, Certificación en Nutrición Deportiva');

SELECT * FROM asistencias;

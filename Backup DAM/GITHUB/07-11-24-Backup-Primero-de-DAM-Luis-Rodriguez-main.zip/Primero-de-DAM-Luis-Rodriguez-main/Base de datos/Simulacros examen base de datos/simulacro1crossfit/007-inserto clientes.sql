INSERT INTO `clientes` (`Nombre`, `Correo`, `Teléfono`, `Fecha_Registro`, `ID_Membresía`) 
VALUES ('Pedro', 'pedro58@yahoo.com', 603001058, '2019-09-14', 2);

INSERT INTO `clientes` (`Nombre`, `Correo`, `Teléfono`, `Fecha_Registro`, `ID_Membresía`) 
VALUES ('Julia', 'julia17@hotmail.com', 673682685, '2021-10-31', 3);

INSERT INTO `clientes` (`Nombre`, `Correo`, `Teléfono`, `Fecha_Registro`, `ID_Membresía`) 
VALUES ('Fernando', 'fernando35@yahoo.com', 613759168, '2020-05-12', 4);

INSERT INTO `clientes` (`Nombre`, `Correo`, `Teléfono`, `Fecha_Registro`, `ID_Membresía`) 
VALUES ('Carmen', 'carmen10@yahoo.com', 610870431, '2020-01-10', 2);

INSERT INTO `clientes` (`Nombre`, `Correo`, `Teléfono`, `Fecha_Registro`, `ID_Membresía`) 
VALUES ('Julia', 'julia25@gmail.com', 677729088, '2022-11-20', 4);

INSERT INTO `clientes` (`Nombre`, `Correo`, `Teléfono`, `Fecha_Registro`, `ID_Membresía`) 
VALUES ('María', 'maría3@yahoo.com', 694913938, '2023-05-09', 2);

INSERT INTO `clientes` (`Nombre`, `Correo`, `Teléfono`, `Fecha_Registro`, `ID_Membresía`) 
VALUES ('María', 'maría7@yahoo.com', 682144544, '2022-07-31', 5);

INSERT INTO `clientes` (`Nombre`, `Correo`, `Teléfono`, `Fecha_Registro`, `ID_Membresía`) 
VALUES ('Roberto', 'roberto55@yahoo.com', 695088382, '2021-01-25', 1);

INSERT INTO `clientes` (`Nombre`, `Correo`, `Teléfono`, `Fecha_Registro`, `ID_Membresía`) 
VALUES ('Carlos', 'carlos68@yahoo.com', 635946435, '2021-07-17', 5);

INSERT INTO `clientes` (`Nombre`, `Correo`, `Teléfono`, `Fecha_Registro`, `ID_Membresía`) 
VALUES ('María', 'maría32@hotmail.com', 637337381, '2021-11-11', 1);

INSERT INTO `clientes` (`Nombre`, `Correo`, `Teléfono`, `Fecha_Registro`, `ID_Membresía`) 
VALUES ('Claudia', 'claudia24@gmail.com', 655538851, '2022-02-12', 1);

INSERT INTO `clientes` (`Nombre`, `Correo`, `Teléfono`, `Fecha_Registro`, `ID_Membresía`) 
VALUES ('Fernando', 'fernando56@hotmail.com', 662042651, '2021-09-12', 1);

INSERT INTO `clientes` (`Nombre`, `Correo`, `Teléfono`, `Fecha_Registro`, `ID_Membresía`) 
VALUES ('María', 'maría37@hotmail.com', 634664208, '2019-08-25', 3);

INSERT INTO `clientes` (`Nombre`, `Correo`, `Teléfono`, `Fecha_Registro`, `ID_Membresía`) 
VALUES ('Carmen', 'carmen44@gmail.com', 616716674, '2019-11-01', 1);

INSERT INTO `clientes` (`Nombre`, `Correo`, `Teléfono`, `Fecha_Registro`, `ID_Membresía`) 
VALUES ('Antonio', 'antonio10@gmail.com', 689501006, '2024-10-14', 4);

INSERT INTO `clientes` (`Nombre`, `Correo`, `Teléfono`, `Fecha_Registro`, `ID_Membresía`) 
VALUES ('Julia', 'julia43@gmail.com', 623681167, '2022-08-16', 1);

INSERT INTO `clientes` (`Nombre`, `Correo`, `Teléfono`, `Fecha_Registro`, `ID_Membresía`) 
VALUES ('Carlos', 'carlos13@gmail.com', 696674101, '2020-12-22', 5);

INSERT INTO `clientes` (`Nombre`, `Correo`, `Teléfono`, `Fecha_Registro`, `ID_Membresía`) 
VALUES ('Claudia', 'claudia43@hotmail.com', 625553664, '2023-07-27', 4);

INSERT INTO `clientes` (`Nombre`, `Correo`, `Teléfono`, `Fecha_Registro`, `ID_Membresía`) 
VALUES ('Jorge', 'jorge98@hotmail.com', 699020059, '2024-01-19', 1);

INSERT INTO `clientes` (`Nombre`, `Correo`, `Teléfono`, `Fecha_Registro`, `ID_Membresía`) 
VALUES ('Jorge', 'jorge39@hotmail.com', 665369144, '2022-05-24', 1);

INSERT INTO `tabla clases` (`Nombre_Clase`, `Horario`, `Capacidad_Maxima`, `ID_Entrenador`)
VALUES
('Yoga Vinyasa', 'Lunes 8:00 AM - 9:00 AM', 20, 1),
('HIIT Intensivo', 'Martes 6:00 PM - 7:00 PM', 15, 2),
('Pilates Reformer', 'Miércoles 10:00 AM - 11:00 AM', 12, 3),
('Entrenamiento Funcional', 'Jueves 7:00 PM - 8:00 PM', 18, 4),
('Zumba Fitness', 'Viernes 5:00 PM - 6:00 PM', 25, 5);

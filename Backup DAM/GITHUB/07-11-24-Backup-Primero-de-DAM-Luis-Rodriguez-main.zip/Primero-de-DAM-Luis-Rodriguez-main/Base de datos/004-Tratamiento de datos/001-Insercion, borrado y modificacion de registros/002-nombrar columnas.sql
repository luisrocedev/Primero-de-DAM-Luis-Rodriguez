INSERT INTO clientes
(
	Identificador,
	nombre,
	apellidos,
	email,
	poblacion,
	fechadenacimiento
)
VALUES
(
	NULL,
	'Jose Vicente',
	'Carratalá Sanchis',
	'info@josevicentecarratala.com',
	'Valencia',
	'1978-04-14'
);

UPDATE clientes
SET nombre = 'Clara María';

INSERT INTO clientes
(
	Identificador,
	apellidos,
	nombre
)
VALUES
(
	NULL,
	'Carratalá Sanchis',
	'Jose Vicente'
);

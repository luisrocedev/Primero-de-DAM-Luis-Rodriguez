INSERT INTO clientes
(
	Identificador,
	apellidos,
	nombre,
	email,
	poblacion,
	fechadenacimiento
)
VALUES
(
	NULL,
	'Carratalá Sanchis',
	'Jose Vicente',
	'info@josevicentecarratala.com',
	'Valencia',
	'1978-04-14'
);

INSERT INTO `direcciones` (`Identificador`, `calle`, `codigopostal`, `pais`, `empleados_nombre`) VALUES (NULL, 'Segunda calle del cliente', '45098', 'España', '1');


SELECT * FROM empleados
right JOIN direcciones
ON empleados.Identificador = direcciones.empleados_nombre;



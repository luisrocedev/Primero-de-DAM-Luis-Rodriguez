SELECT * FROM empleados
INNER JOIN direcciones
ON empleados.Identificador = direcciones.empleados_nombre;



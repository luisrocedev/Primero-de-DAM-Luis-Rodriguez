CREATE TABLE `miempresa`.`pedidos` (`Identificador` INT NOT NULL AUTO_INCREMENT , `fecha` DATE NOT NULL , `clientes_apellidos` INT NOT NULL , PRIMARY KEY (`Identificador`)) ENGINE = InnoDB;


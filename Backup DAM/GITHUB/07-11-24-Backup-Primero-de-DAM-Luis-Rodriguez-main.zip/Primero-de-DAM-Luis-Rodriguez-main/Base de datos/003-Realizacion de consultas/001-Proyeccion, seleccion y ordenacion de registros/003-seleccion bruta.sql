INSERT INTO `miempresa`.`clientes` (`nombre`, `apellidos`, `email`, `poblacion`, `fechadenacimiento`) VALUES
('Carlos', 'Gómez Pérez', 'carlos.gomez@example.com', 'Madrid', '1985-07-13'),
('Lucía', 'Fernández García', 'lucia.fernandez@example.com', 'Barcelona', '1990-04-22'),
('Javier', 'Martínez López', 'javier.martinez@example.com', 'Valencia', '1983-11-30'),
('María', 'Rodríguez Sánchez', 'maria.rodriguez@example.com', 'Sevilla', '1992-06-10'),
('Pablo', 'Díaz Torres', 'pablo.diaz@example.com', 'Bilbao', '1987-09-25'),
('Sara', 'Hernández Ruiz', 'sara.hernandez@example.com', 'Zaragoza', '1995-02-14'),
('Andrés', 'Jiménez Gómez', 'andres.jimenez@example.com', 'Alicante', '1980-03-19'),
('Ana', 'López Martínez', 'ana.lopez@example.com', 'Granada', '1993-05-07'),
('Manuel', 'Pérez Ortega', 'manuel.perez@example.com', 'Córdoba', '1989-08-17'),
('Elena', 'Sánchez Muñoz', 'elena.sanchez@example.com', 'Málaga', '1991-12-03');
INSERT INTO `miempresa`.`clientes` (`nombre`, `apellidos`, `email`, `poblacion`, `fechadenacimiento`) VALUES
('Alberto', 'Romero Pérez', 'alberto.romero@example.com', 'Salamanca', '1984-01-12'),
('Clara', 'Vega González', 'clara.vega@example.com', 'Pamplona', '1996-07-18'),
('Miguel', 'Navarro Torres', 'miguel.navarro@example.com', 'Murcia', '1979-10-23'),
('Paula', 'Castro Jiménez', 'paula.castro@example.com', 'Logroño', '1991-11-05'),
('Raúl', 'Santos Morales', 'raul.santos@example.com', 'Santander', '1988-09-15'),
('Cristina', 'Gil Fernández', 'cristina.gil@example.com', 'Oviedo', '1994-03-08'),
('Iván', 'Ortega Martínez', 'ivan.ortega@example.com', 'Valladolid', '1982-06-21'),
('Beatriz', 'Lorenzo Ruiz', 'beatriz.lorenzo@example.com', 'Toledo', '1986-02-27'),
('Sergio', 'Cano Ortiz', 'sergio.cano@example.com', 'Almería', '1993-05-10'),
('Laura', 'Molina Reyes', 'laura.molina@example.com', 'León', '1990-12-17');
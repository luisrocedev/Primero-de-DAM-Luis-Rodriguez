SELECT
Identificador AS "ID de MySQL",
nombre AS "Nombre de cliente",
apellidos AS "Apellidos del cliente"
FROM clientes
ORDER BY
apellidos,nombre ASC
;
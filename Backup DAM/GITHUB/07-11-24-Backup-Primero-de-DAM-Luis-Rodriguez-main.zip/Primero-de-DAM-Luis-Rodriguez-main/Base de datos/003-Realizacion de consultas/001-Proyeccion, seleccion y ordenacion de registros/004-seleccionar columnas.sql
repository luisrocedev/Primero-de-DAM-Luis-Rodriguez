SELECT
nombre,
apellidos
FROM clientes;
SELECT
Identificador AS "ID de MySQL",
nombre AS "Nombre de cliente",
apellidos AS "Apellidos del cliente",
(5+5) AS "Te lo sumo porque puedo"
FROM clientes
;
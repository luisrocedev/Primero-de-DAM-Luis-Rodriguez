import sqlite3

conexion = sqlite3.connect('registros.db')

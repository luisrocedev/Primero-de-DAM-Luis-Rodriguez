DELETE FROM empleados
WHERE identificador = 2
;
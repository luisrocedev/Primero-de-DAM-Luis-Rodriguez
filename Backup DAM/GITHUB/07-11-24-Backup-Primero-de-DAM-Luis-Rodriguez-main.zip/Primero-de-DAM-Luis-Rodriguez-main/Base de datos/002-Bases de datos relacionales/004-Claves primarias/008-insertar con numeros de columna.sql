INSERT INTO empleados
(
    Identificador,
    nombre,
    apellidos,
    telefono,
    email
)
VALUES
(
    NULL,
    "Luis",
    "Rodriguez Cedenio",
    "722152111",
    "luis@gmail.com"
);
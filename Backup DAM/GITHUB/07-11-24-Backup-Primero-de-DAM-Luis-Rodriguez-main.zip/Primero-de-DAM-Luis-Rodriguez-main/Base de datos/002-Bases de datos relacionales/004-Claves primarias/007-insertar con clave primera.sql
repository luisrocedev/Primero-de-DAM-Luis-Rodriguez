INSERT INTO empleados VALUES(
    NULL,
    "Luis",
    "Rodriguez Cedenio",
    "722152111",
    "luis@gmail.com"
);
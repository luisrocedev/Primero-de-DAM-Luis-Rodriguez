import tkinter as tk

raiz = tk.Tk()

tk.Button(raiz,text="Venga pulsame").pack()

raiz.mainloop()

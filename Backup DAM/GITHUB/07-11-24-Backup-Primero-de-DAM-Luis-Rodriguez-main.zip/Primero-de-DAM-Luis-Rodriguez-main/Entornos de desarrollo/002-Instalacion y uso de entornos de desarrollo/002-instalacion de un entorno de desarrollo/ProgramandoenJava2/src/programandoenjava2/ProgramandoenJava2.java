/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package programandoenjava2;

/**
 *
 * @author Luis
 */
public class ProgramandoenJava2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int edad = 25;
        String nombre = "Luis";
        System.out.println("Mi nombre es "+nombre+" y mi edad es de "+edad);
    }
    
}

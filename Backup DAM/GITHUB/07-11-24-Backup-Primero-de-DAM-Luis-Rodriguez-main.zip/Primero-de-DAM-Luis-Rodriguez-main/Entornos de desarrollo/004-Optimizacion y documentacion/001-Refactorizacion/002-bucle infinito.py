print("Bienvenidos a mi agenda")
print("Agenda v0.1 por Luis Rodrigiuez")

while True:

    print("Menú principal")
    print("1.-Insertar un registro")
    print("2.-Leer registros")
    print("3.-Actualizar un registro")
    print("4.-Eliminar registros")

    entrada = input("Selecciona una opcion:")

    if entrada == "1":
        print("Vamos a insertar un registro")
        print("accion")
        print("accion")
        print("accion")
        print("accion")
        print("accion")
        print("accion")
        print("accion")
    elif entrada == "2":
        print("Vamos a listar registros")
        print("accion")
        print("accion")
        print("accion")
        print("accion")
        print("accion")
        print("accion")
        print("accion")
    elif entrada == "3":
        print("Vamos a actualizar un registro")
        print("accion")
        print("accion")
        print("accion")
        print("accion")
        print("accion")
        print("accion")
        print("accion")
    elif entrada == "4":
        print("Vamos a eliminar registros")
        print("accion")
        print("accion")
        print("accion")
        print("accion")
        print("accion")
        print("accion")
        print("accion")
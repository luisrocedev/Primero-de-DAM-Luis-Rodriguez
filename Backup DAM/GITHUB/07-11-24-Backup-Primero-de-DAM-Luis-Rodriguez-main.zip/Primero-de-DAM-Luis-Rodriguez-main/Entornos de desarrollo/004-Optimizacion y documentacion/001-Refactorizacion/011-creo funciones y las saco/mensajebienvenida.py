def bienvenida():
    print("###############################################")                        # Creo un mensaje de bienvenida
    print("Programa agenda con pickle por Luis Rodriguez")
    print("###############################################")

def menu():
    print("Menú de navegación")                                                 # Imprimo un menu de navegacion
    print("1.-Introduce un registro")
    print("2.-Listado de registros")
    print("3.-Guardar registros")
    print("4.-Leer registros")
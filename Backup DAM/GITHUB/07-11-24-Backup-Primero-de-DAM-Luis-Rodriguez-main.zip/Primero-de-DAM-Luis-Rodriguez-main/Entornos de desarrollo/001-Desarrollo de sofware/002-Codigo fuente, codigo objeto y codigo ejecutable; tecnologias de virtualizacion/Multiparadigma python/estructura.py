print ("hola mundo")

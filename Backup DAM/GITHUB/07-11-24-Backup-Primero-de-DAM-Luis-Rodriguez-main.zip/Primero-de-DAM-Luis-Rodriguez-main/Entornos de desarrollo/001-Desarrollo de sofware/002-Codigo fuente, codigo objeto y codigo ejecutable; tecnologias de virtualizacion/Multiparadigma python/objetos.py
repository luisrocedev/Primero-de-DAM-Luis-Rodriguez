class Gato:
    def __init__(self, nombre, edad):
        self.nombre = nombre
        self.edad = edad

gato = Gato("Micifu", 2)
print(f"Hola, mi nombre es {gato.nombre} y tengo {gato.edad} años.")

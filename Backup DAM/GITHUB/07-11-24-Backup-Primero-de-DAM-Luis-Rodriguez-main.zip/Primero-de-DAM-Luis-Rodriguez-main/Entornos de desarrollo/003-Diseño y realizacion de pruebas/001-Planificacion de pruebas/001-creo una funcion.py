def division(dividiendo,divisor):
    if divisor == 0:
        return False
    else:
        return True
print(division(4,3))
print(division(4,2))
print(division(4,1))
print(division(4,0))

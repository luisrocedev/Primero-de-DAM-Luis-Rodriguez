<?php
require_once '../controllers/EntrenadorController.php';

$controller = new EntrenadorController();
$controller->handleRequest();
?>

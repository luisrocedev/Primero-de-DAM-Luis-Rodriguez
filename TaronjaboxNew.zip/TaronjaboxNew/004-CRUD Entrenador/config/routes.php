<?php
return [
    'home' => '/front/views/home.php',
    'entrenadores' => '/front/controllers/Entrenador/ListEntrenadorController.php',
    'precios' => '/front/controllers/Precio/ShowPrecioController.php',
    'blog' => '/front/controllers/Blog/ListBlogController.php',
];
?>

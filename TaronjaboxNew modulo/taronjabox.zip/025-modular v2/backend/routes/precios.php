<?php
require_once '../controllers/PrecioController.php';

$controller = new PrecioController();
$controller->handleRequest();
?>

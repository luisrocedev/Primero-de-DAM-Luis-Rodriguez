<section id="hero">
    <h1>Bienvenido a TaronjaBox</h1>
    <p>Transforma tu vida con el mejor entrenamiento de CrossFit.</p>
    <a href="modulos/sobre_nosotros/sobre_nosotros.php" class="cta-button">Conócenos</a>
</section>

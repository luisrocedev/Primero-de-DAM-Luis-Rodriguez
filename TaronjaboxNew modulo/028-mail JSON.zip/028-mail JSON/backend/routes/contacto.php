<?php
require_once '../controllers/ContactoController.php';

$controller = new ContactoController();
$controller->handleRequest();
?>

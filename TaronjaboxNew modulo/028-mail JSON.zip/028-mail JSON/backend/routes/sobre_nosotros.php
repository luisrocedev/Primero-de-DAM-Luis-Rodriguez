<?php
require_once '../controllers/SobreNosotrosController.php';

$controller = new SobreNosotrosController();
$controller->handleRequest();
?>

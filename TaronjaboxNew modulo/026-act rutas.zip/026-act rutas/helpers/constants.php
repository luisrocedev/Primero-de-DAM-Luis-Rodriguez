<?php
define('BASE_URL', 'http://localhost/025-organizacion');
define('ADMIN_URL', BASE_URL . '/admin');
define('FRONT_URL', BASE_URL . '/front');
define('BACKEND_URL', BASE_URL . '/backend');
define('UPLOADS_URL', BASE_URL . '/uploads');
?>

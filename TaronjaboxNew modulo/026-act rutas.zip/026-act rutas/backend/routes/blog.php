<?php
require_once '../controllers/BlogController.php';

$controller = new BlogController();
$controller->handleRequest();
?>

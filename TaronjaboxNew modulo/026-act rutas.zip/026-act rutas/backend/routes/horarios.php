<?php
require_once '../controllers/HorarioController.php';

$controller = new HorarioController();
$controller->handleRequest();
?>

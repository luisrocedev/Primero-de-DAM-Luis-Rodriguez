<?php
// admin/blog/index.php

session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.php");  // Redirigir al login si no está autenticado
    exit();
}

// Incluir el archivo de conexión a la base de datos
include "../config/db_connect.php";

// Mensaje de confirmación o error
$message = "";
if (isset($_GET['message'])) {
    $message = htmlspecialchars($_GET['message']);
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión del Blog</title>
    <link rel="stylesheet" href="../css/header.css"> <!-- Estilos del panel de administración -->
    <link rel="stylesheet" href="../css/style.css"> <!-- Estilos generales -->
</head>

<body>
    <header>
        <nav>
            <ul>
                <li><a href="../../dashboard.php">Inicio</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h2>Gestión del Blog</h2>

        <!-- Mensaje de confirmación o error -->
        <?php if (!empty($message)) : ?>
            <p class="message"><?= $message ?></p>
        <?php endif; ?>

        <!-- Enlace para crear una nueva entrada -->
        <a href="../crud/create.php?tabla=blog_posts">Crear Nueva Entrada</a>
        <br><br>

        <!-- Lista de entradas existentes -->
        <h3>Entradas Existentes</h3>
        <?php
        // Obtener todas las entradas de la tabla blog_posts
        $peticion = "SELECT * FROM blog_posts";
        $resultado = $conexion->query($peticion);

        if ($resultado && $resultado->num_rows > 0) :
        ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Título</th>
                        <th>Contenido</th>
                        <th>Fecha de Creación</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($fila = $resultado->fetch_assoc()) : ?>
                        <tr>
                            <td><?= htmlspecialchars($fila['id']) ?></td>
                            <td><?= htmlspecialchars($fila['title']) ?></td>
                            <td><?= htmlspecialchars($fila['content']) ?></td>
                            <td><?= htmlspecialchars($fila['created_at']) ?></td>
                            <td>
                                <a href="../crud/update.php?tabla=blog_posts&id=<?= $fila['id'] ?>">Editar</a>
                                <a href="../crud/delete.php?tabla=blog_posts&id=<?= $fila['id'] ?>" onclick="return confirm('¿Estás seguro de eliminar esta entrada?');">Eliminar</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else : ?>
            <p>No hay entradas en el blog.</p>
        <?php endif; ?>
    </main>

    <footer>
        <p>&copy; 2025 TaronjaBox. Todos los derechos reservados.</p>
    </footer>
</body>

</html>
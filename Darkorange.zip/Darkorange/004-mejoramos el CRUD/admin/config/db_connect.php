<?php
// admin/config/db_connect.php

$servername = "localhost";
$username = "taronjaboxvalencia";
$password = "taronjaboxvalencia";
$database = "taronjaboxvalencia";

// Crear conexión
$conexion = new mysqli($servername, $username, $password, $database);

// Verificar conexión
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

<?php
// admin/crud/create.php

session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.php");  // Redirigir al login si no está autenticado
    exit();
}

// Incluir el archivo de conexión a la base de datos
include "../config/db_connect.php";

// Verificar si se ha proporcionado la tabla
if (!isset($_GET['tabla'])) {
    die("Error: No se ha especificado la tabla.");
}

$tabla = $_GET['tabla'];

// Si la solicitud es POST, procesar los datos del formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtener los datos del formulario
    $title = $conexion->real_escape_string($_POST['title']);
    $content = $conexion->real_escape_string($_POST['content']);
    $created_at = date('Y-m-d H:i:s'); // Fecha y hora actual

    // Construir la consulta SQL
    $peticion = "INSERT INTO $tabla (title, content, created_at) VALUES ('$title', '$content', '$created_at')";

    // Ejecutar la consulta
    if ($conexion->query($peticion)) {
        $message = "Entrada creada con éxito.";
    } else {
        $message = "Error en la inserción: " . $conexion->error;
    }

    // Redirigir a dashboard.php con un mensaje
    header("Location: ../../dashboard.php?message=" . urlencode($message));
    exit();
}

// Si la solicitud es GET, mostrar el formulario
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Nueva Entrada</title>
    <link rel="stylesheet" href="../css/style.css"> <!-- Estilos generales -->
</head>

<body>
    <header>
        <nav>
            <ul>
                <li><a href="../../dashboard.php">Inicio</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h2>Crear Nueva Entrada</h2>

        <!-- Formulario para crear una nueva entrada -->
        <form action="create.php?tabla=<?= htmlspecialchars($tabla) ?>" method="post">
            <label for="title">Título:</label>
            <input type="text" name="title" id="title" required>
            <br><br>

            <label for="content">Contenido:</label>
            <textarea name="content" id="content" required></textarea>
            <br><br>

            <button type="submit">Crear Entrada</button>
        </form>
    </main>

    <footer>
        <p>&copy; 2025 TaronjaBox. Todos los derechos reservados.</p>
    </footer>
</body>

</html>
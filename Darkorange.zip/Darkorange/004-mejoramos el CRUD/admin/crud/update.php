<?php
// admin/crud/update.php

session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['user_id'])) {
	header("Location: ../../login.php");  // Redirigir al login si no está autenticado
	exit();
}

// Incluir el archivo de conexión a la base de datos
include "../config/db_connect.php";

// Verificar si se han proporcionado la tabla y el ID
if (!isset($_GET['tabla']) || !isset($_GET['id'])) {
	die("Error: Parámetros incompletos.");
}

$tabla = $_GET['tabla'];
$id = $_GET['id'];

// Si la solicitud es POST, procesar los datos del formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	// Obtener los datos del formulario
	$title = $conexion->real_escape_string($_POST['title']);
	$content = $conexion->real_escape_string($_POST['content']);

	// Construir la consulta SQL
	$peticion = "UPDATE $tabla SET title = '$title', content = '$content' WHERE id = $id";

	// Ejecutar la consulta
	if ($conexion->query($peticion)) {
		$message = "Registro actualizado con éxito.";
	} else {
		$message = "Error al actualizar el registro: " . $conexion->error;
	}

	// Redirigir a dashboard.php con un mensaje
	header("Location: ../../dashboard.php?message=" . urlencode($message));
	exit();
}

// Si la solicitud es GET, obtener el registro actual
$peticion = "SELECT * FROM $tabla WHERE id = $id";
$resultado = $conexion->query($peticion);

if (!$resultado || $resultado->num_rows === 0) {
	die("Error: Registro no encontrado.");
}

$fila = $resultado->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="es">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Editar Entrada</title>
	<link rel="stylesheet" href="../css/style.css"> <!-- Estilos generales -->
</head>

<body>
	<header>
		<nav>
			<ul>
				<li><a href="../../dashboard.php">Inicio</a></li>
			</ul>
		</nav>
	</header>

	<main>
		<h2>Editar Entrada</h2>

		<!-- Formulario para editar la entrada -->
		<form action="update.php?tabla=<?= htmlspecialchars($tabla) ?>&id=<?= htmlspecialchars($id) ?>" method="post">
			<label for="title">Título:</label>
			<input type="text" name="title" id="title" value="<?= htmlspecialchars($fila['title']) ?>" required>
			<br><br>

			<label for="content">Contenido:</label>
			<textarea name="content" id="content" required><?= htmlspecialchars($fila['content']) ?></textarea>
			<br><br>

			<button type="submit">Actualizar Entrada</button>
		</form>
	</main>

	<footer>
		<p>&copy; 2025 TaronjaBox. Todos los derechos reservados.</p>
	</footer>
</body>

</html>
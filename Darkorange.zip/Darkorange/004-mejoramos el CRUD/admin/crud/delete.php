<?php
// admin/crud/delete.php

session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.php");  // Redirigir al login si no está autenticado
    exit();
}

// Incluir el archivo de conexión a la base de datos
include "../config/db_connect.php";

// Verificar si se han proporcionado la tabla y el ID
if (!isset($_GET['tabla']) || !isset($_GET['id'])) {
    die("Error: Parámetros incompletos.");
}

$tabla = $_GET['tabla'];
$id = $_GET['id'];

// Construir la consulta SQL
$peticion = "DELETE FROM $tabla WHERE id = $id";

// Ejecutar la consulta
if ($conexion->query($peticion)) {
    $message = "Registro eliminado con éxito.";
} else {
    $message = "Error al eliminar el registro: " . $conexion->error;
}

// Redirigir a dashboard.php con un mensaje
header("Location: ../../dashboard.php?message=" . urlencode($message));
exit();

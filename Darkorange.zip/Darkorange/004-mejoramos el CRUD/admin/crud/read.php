<?php
// admin/crud/read.php

session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.php");  // Redirigir al login si no está autenticado
    exit();
}

// Incluir el archivo de conexión a la base de datos
include "../config/db_connect.php";

// Verificar si se ha proporcionado la tabla
if (!isset($_GET['tabla'])) {
    die("Error: No se ha especificado la tabla.");
}

$tabla = $_GET['tabla'];

// Obtener todos los registros de la tabla
$peticion = "SELECT * FROM $tabla";
$resultado = $conexion->query($peticion);

if (!$resultado) {
    die("Error al obtener los registros: " . $conexion->error);
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver Entradas</title>
    <link rel="stylesheet" href="../css/style.css"> <!-- Estilos generales -->
</head>

<body>
    <header>
        <nav>
            <ul>
                <li><a href="../../dashboard.php">Inicio</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h2>Entradas del Blog</h2>

        <!-- Lista de entradas -->
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Título</th>
                    <th>Contenido</th>
                    <th>Fecha de Creación</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($fila = $resultado->fetch_assoc()) : ?>
                    <tr>
                        <td><?= htmlspecialchars($fila['id']) ?></td>
                        <td><?= htmlspecialchars($fila['title']) ?></td>
                        <td><?= htmlspecialchars($fila['content']) ?></td>
                        <td><?= htmlspecialchars($fila['created_at']) ?></td>
                        <td>
                            <a href="update.php?tabla=<?= $tabla ?>&id=<?= $fila['id'] ?>">Editar</a>
                            <a href="delete.php?tabla=<?= $tabla ?>&id=<?= $fila['id'] ?>" onclick="return confirm('¿Estás seguro de eliminar esta entrada?');">Eliminar</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </main>

    <footer>
        <p>&copy; 2025 TaronjaBox. Todos los derechos reservados.</p>
    </footer>
</body>

</html>
<?php
// admin/fisioterapia/index.php

session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.php");  // Redirigir al login si no está autenticado
    exit();
}

// Incluir el archivo de conexión a la base de datos
include "../config/db_connect.php";

// Mensaje de confirmación o error
$message = "";
if (isset($_GET['message'])) {
    $message = htmlspecialchars($_GET['message']);
}

// Definir la sección actual
$seccion = "fisioterapia"; // Esto indica que estamos en la sección "fisioterapia"
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Fisioterapia</title>
    <link rel="stylesheet" href="../css/header.css"> <!-- Estilos del panel de administración -->
    <link rel="stylesheet" href="../css/style.css"> <!-- Estilos generales -->
</head>

<body>
    <header>
        <nav>
            <ul>
                <li><a href="../../dashboard.php">Inicio</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h2>Gestión de Servicios de Fisioterapia</h2>

        <!-- Mensaje de confirmación o error -->
        <?php if (!empty($message)) : ?>
            <p class="message"><?= $message ?></p>
        <?php endif; ?>

        <!-- Enlace para crear un nuevo servicio -->
        <a href="../crud/create.php?tabla=fisioterapia&seccion=<?= $seccion ?>">Crear Nuevo Servicio</a>
        <br><br>

        <!-- Lista de servicios existentes -->
        <h3>Servicios Existentes</h3>
        <?php
        // Obtener todos los servicios de la tabla fisioterapia
        $peticion = "SELECT * FROM fisioterapia";
        $resultado = $conexion->query($peticion);

        if ($resultado && $resultado->num_rows > 0) :
        ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Descripción</th>
                        <th>Costo</th>
                        <th>Fecha de Creación</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($fila = $resultado->fetch_assoc()) : ?>
                        <tr>
                            <td><?= htmlspecialchars($fila['id']) ?></td>
                            <td><?= htmlspecialchars($fila['nombre']) ?></td>
                            <td><?= htmlspecialchars($fila['descripcion']) ?></td>
                            <td><?= htmlspecialchars($fila['costo']) ?></td>
                            <td><?= htmlspecialchars($fila['fecha_creacion']) ?></td>
                            <td>
                                <a href="../crud/update.php?tabla=fisioterapia&id=<?= $fila['id'] ?>&seccion=<?= $seccion ?>">Editar</a>
                                <a href="../crud/delete.php?tabla=fisioterapia&id=<?= $fila['id'] ?>&seccion=<?= $seccion ?>" onclick="return confirm('¿Estás seguro de eliminar este servicio?');">Eliminar</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else : ?>
            <p>No hay servicios de fisioterapia registrados.</p>
        <?php endif; ?>
    </main>

    <footer>
        <p>&copy; 2025 TaronjaBox. Todos los derechos reservados.</p>
    </footer>
</body>

</html>
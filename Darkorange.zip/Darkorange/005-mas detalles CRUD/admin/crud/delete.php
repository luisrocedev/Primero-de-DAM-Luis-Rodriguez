<?php
// admin/crud/delete.php

session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.php");  // Redirigir al login si no está autenticado
    exit();
}

// Incluir el archivo de conexión a la base de datos
include "../config/db_connect.php";

// Verificar si se han proporcionado la tabla, el ID y la sección
if (!isset($_GET['tabla']) || !isset($_GET['id']) || !isset($_GET['seccion'])) {
    die("Error: Parámetros incompletos.");
}

$tabla = $_GET['tabla'];
$id = $_GET['id'];
$seccion = $_GET['seccion'];

// Construir la consulta SQL
$peticion = "DELETE FROM $tabla WHERE id = $id";

// Ejecutar la consulta
if ($conexion->query($peticion)) {
    $message = "Registro eliminado con éxito.";
} else {
    $message = "Error al eliminar el registro: " . $conexion->error;
}

// Redirigir a la sección correcta con un mensaje
header("Location: ../../admin/$seccion/index.php?message=" . urlencode($message));
exit();

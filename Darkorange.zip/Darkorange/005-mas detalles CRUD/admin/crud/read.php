<?php
// admin/crud/read.php

session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.php");  // Redirigir al login si no está autenticado
    exit();
}

// Incluir el archivo de conexión a la base de datos
include "../config/db_connect.php";

// Verificar si se ha proporcionado la tabla
if (!isset($_GET['tabla']) || !isset($_GET['seccion'])) {
    die("Error: Parámetros incompletos.");
}

$tabla = $_GET['tabla'];
$seccion = $_GET['seccion'];

// Obtener todos los registros de la tabla
$peticion = "SELECT * FROM $tabla";
$resultado = $conexion->query($peticion);

if (!$resultado) {
    die("Error al obtener los registros: " . $conexion->error);
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver Registros</title>
    <link rel="stylesheet" href="../css/style.css"> <!-- Estilos generales -->
</head>

<body>
    <header>
        <nav>
            <ul>
                <li><a href="../../dashboard.php">Inicio</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h2>Registros de <?= ucfirst($tabla) ?></h2>

        <!-- Lista de registros -->
        <table>
            <thead>
                <tr>
                    <?php
                    // Obtener los nombres de las columnas
                    $peticionColumnas = "DESCRIBE $tabla";
                    $resultadoColumnas = $conexion->query($peticionColumnas);

                    if ($resultadoColumnas) :
                        while ($columna = $resultadoColumnas->fetch_assoc()) :
                    ?>
                            <th><?= ucfirst($columna['Field']) ?></th>
                    <?php
                        endwhile;
                    endif;
                    ?>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($fila = $resultado->fetch_assoc()) : ?>
                    <tr>
                        <?php
                        // Mostrar los valores de cada columna
                        foreach ($fila as $valor) :
                        ?>
                            <td><?= htmlspecialchars($valor) ?></td>
                        <?php endforeach; ?>
                        <td>
                            <a href="update.php?tabla=<?= $tabla ?>&id=<?= $fila['id'] ?>&seccion=<?= $seccion ?>">Editar</a>
                            <a href="delete.php?tabla=<?= $tabla ?>&id=<?= $fila['id'] ?>&seccion=<?= $seccion ?>" onclick="return confirm('¿Estás seguro de eliminar este registro?');">Eliminar</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </main>

    <footer>
        <p>&copy; 2025 TaronjaBox. Todos los derechos reservados.</p>
    </footer>
</body>

</html>
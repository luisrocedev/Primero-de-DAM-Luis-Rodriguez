<?php
// admin/crud/create.php

session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.php");  // Redirigir al login si no está autenticado
    exit();
}

// Incluir el archivo de conexión a la base de datos
include "../config/db_connect.php";

// Verificar si se han proporcionado la tabla y la sección
if (!isset($_GET['tabla']) || !isset($_GET['seccion'])) {
    die("Error: Parámetros incompletos.");
}

$tabla = $_GET['tabla'];
$seccion = $_GET['seccion'];

// Obtener la estructura de la tabla (columnas)
$peticion = "DESCRIBE $tabla";
$resultado = $conexion->query($peticion);

if (!$resultado) {
    die("Error al obtener la estructura de la tabla: " . $conexion->error);
}

// Si la solicitud es POST, procesar los datos del formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $campos = [];
    $valores = [];

    // Recorrer las columnas de la tabla
    while ($columna = $resultado->fetch_assoc()) {
        $nombreColumna = $columna['Field'];

        // Ignorar la columna autoincremental (generalmente "id")
        if ($columna['Extra'] === 'auto_increment') {
            continue;
        }

        // Si la columna es un timestamp y tiene un valor por defecto, usar ese valor
        if ($columna['Type'] === 'timestamp' && $columna['Default'] === 'CURRENT_TIMESTAMP') {
            continue;
        }

        // Obtener el valor del formulario
        if (isset($_POST[$nombreColumna])) {
            $valor = $_POST[$nombreColumna];

            // Validar y sanitizar el valor según el tipo de columna
            if (strpos($columna['Type'], 'decimal') !== false || strpos($columna['Type'], 'int') !== false) {
                // Eliminar símbolos no numéricos (como €)
                $valor = preg_replace('/[^0-9.]/', '', $valor);
            }

            $campos[] = $nombreColumna;
            $valores[] = "'" . $conexion->real_escape_string($valor) . "'";
        }
    }

    // Construir la consulta SQL
    $camposStr = implode(", ", $campos);
    $valoresStr = implode(", ", $valores);
    $peticion = "INSERT INTO $tabla ($camposStr) VALUES ($valoresStr)";

    // Ejecutar la consulta
    if ($conexion->query($peticion)) {
        $message = "Registro creado con éxito.";
    } else {
        $message = "Error al crear el registro: " . $conexion->error;
    }

    // Redirigir a la sección correcta con un mensaje
    header("Location: ../../admin/$seccion/index.php?message=" . urlencode($message));
    exit();
}

// Si la solicitud es GET, mostrar el formulario
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Nuevo Registro</title>
    <link rel="stylesheet" href="../css/style.css"> <!-- Estilos generales -->
</head>

<body>
    <header>
        <nav>
            <ul>
                <li><a href="../../dashboard.php">Inicio</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h2>Crear Nuevo Registro</h2>

        <!-- Formulario dinámico -->
        <form action="create.php?tabla=<?= htmlspecialchars($tabla) ?>&seccion=<?= htmlspecialchars($seccion) ?>" method="post">
            <?php
            // Recorrer las columnas de la tabla
            $resultado->data_seek(0); // Reiniciar el puntero del resultado
            while ($columna = $resultado->fetch_assoc()) :
                $nombreColumna = $columna['Field'];

                // Ignorar la columna autoincremental (generalmente "id")
                if ($columna['Extra'] === 'auto_increment') {
                    continue;
                }

                // Ignorar columnas con valores por defecto (como timestamps)
                if ($columna['Type'] === 'timestamp' && $columna['Default'] === 'CURRENT_TIMESTAMP') {
                    continue;
                }
            ?>
                <label for="<?= $nombreColumna ?>"><?= ucfirst($nombreColumna) ?>:</label>
                <?php if ($columna['Type'] === 'text') : ?>
                    <textarea name="<?= $nombreColumna ?>" id="<?= $nombreColumna ?>" required></textarea>
                <?php elseif (strpos($columna['Type'], 'decimal') !== false || strpos($columna['Type'], 'int') !== false) : ?>
                    <input type="number" step="0.01" name="<?= $nombreColumna ?>" id="<?= $nombreColumna ?>" required>
                <?php else : ?>
                    <input type="text" name="<?= $nombreColumna ?>" id="<?= $nombreColumna ?>" required>
                <?php endif; ?>
                <br><br>
            <?php endwhile; ?>
            <button type="submit">Crear Registro</button>
        </form>
    </main>

    <footer>
        <p>&copy; 2025 TaronjaBox. Todos los derechos reservados.</p>
    </footer>
</body>

</html>
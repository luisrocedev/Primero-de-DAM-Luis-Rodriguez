<?php
// admin/crud/editar.php

session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['user_id'])) {
	header("Location: ../../login.php");  // Redirigir al login si no está autenticado
	exit();
}

// Incluir el archivo de conexión a la base de datos
include "../config/db_connect.php";

// Verificar si se han proporcionado la tabla y el ID
if (!isset($_GET['tabla']) || !isset($_GET['id'])) {
	die("Error: Parámetros incompletos.");
}

$tabla = $_GET['tabla'];
$id = $_GET['id'];

// Obtener el registro actual
$peticion = "SELECT * FROM $tabla WHERE id = $id";
$resultado = $conexion->query($peticion);

if (!$resultado || $resultado->num_rows === 0) {
	die("Error: Registro no encontrado.");
}

$fila = $resultado->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="es">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Editar Servicio</title>
	<link rel="stylesheet" href="../css/style.css"> <!-- Estilos generales -->
</head>

<body>
	<header>
		<nav>
			<ul>
				<li><a href="../../dashboard.php">Inicio</a></li>
			</ul>
		</nav>
	</header>

	<main>
		<h2>Editar Servicio</h2>

		<!-- Formulario de edición -->
		<form action="update.php?tabla=fisioterapia&id=<?= $id ?>&seccion=fisioterapia" method="post">
			<label for="nombre">Nombre:</label>
			<input type="text" name="nombre" id="nombre" value="<?= htmlspecialchars($fila['nombre']) ?>" required>
			<br><br>
			<label for="descripcion">Descripción:</label>
			<textarea name="descripcion" id="descripcion" required><?= htmlspecialchars($fila['descripcion']) ?></textarea>
			<br><br>
			<label for="costo">Costo:</label>
			<input type="number" step="0.01" name="costo" id="costo" value="<?= htmlspecialchars($fila['costo']) ?>" required>
			<br><br>
			<button type="submit">Actualizar</button>
		</form>
	</main>

	<footer>
		<p>&copy; 2025 TaronjaBox. Todos los derechos reservados.</p>
	</footer>
</body>

</html>
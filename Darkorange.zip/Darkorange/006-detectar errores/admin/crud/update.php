<?php
// admin/crud/update.php

session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['user_id'])) {
	header("Location: ../../login.php");  // Redirigir al login si no está autenticado
	exit();
}

// Incluir la conexión a la base de datos y funciones
include "../config/db_connect.php";
include "../util/funciones.php";

// Verificar si se han proporcionado la tabla, el ID y la sección
if (!isset($_GET['tabla'], $_GET['id'], $_GET['seccion'])) {
	die("Error: Parámetros incompletos.");
}

$tabla = $_GET['tabla'];
$id = $_GET['id'];
$seccion = $_GET['seccion'];

// Obtener la estructura de la tabla
$estructura = obtenerEstructuraTabla($conexion, $tabla);

// Obtener el registro actual
$peticion = $conexion->prepare("SELECT * FROM $tabla WHERE id = ?");
if (!$peticion) {
	die("Error en la preparación de la consulta: " . $conexion->error);
}

$peticion->bind_param("i", $id); // "i" indica que el parámetro es un entero
$peticion->execute();
$resultado = $peticion->get_result();
$registro = $resultado->fetch_assoc();

if (!$registro) {
	die("Error: Registro no encontrado.");
}

// Si se envía el formulario, procesar los datos
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$actualizaciones = [];

	foreach ($estructura as $columna) {
		$nombre = $columna['Field'];

		// Ignorar columnas autoincrementales y timestamps
		if ($columna['Extra'] === 'auto_increment' || ($columna['Type'] === 'timestamp' && $columna['Default'] === 'CURRENT_TIMESTAMP')) {
			continue;
		}

		if (isset($_POST[$nombre])) {
			$valor = $_POST[$nombre];
			$actualizaciones[] = "$nombre = '" . $conexion->real_escape_string($valor) . "'";
		}
	}

	// Construir la consulta SQL
	$actualizacionesStr = implode(", ", $actualizaciones);
	$peticion = "UPDATE $tabla SET $actualizacionesStr WHERE id = $id";

	// Ejecutar la consulta
	if ($conexion->query($peticion)) {
		$message = "Registro actualizado con éxito.";
	} else {
		$message = "Error al actualizar el registro: " . $conexion->error;
	}

	// Redirigir a la sección correcta con un mensaje
	header("Location: ../../admin/$seccion/index.php?message=" . urlencode($message));
	exit();
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Editar Registro</title>
	<link rel="stylesheet" href="../css/style.css"> <!-- Estilos generales -->
</head>

<body>
	<header>
		<nav>
			<ul>
				<li><a href="../../dashboard.php">Inicio</a></li>
			</ul>
		</nav>
	</header>

	<main>
		<h2>Editar Registro</h2>

		<!-- Formulario dinámico -->
		<form action="update.php?tabla=<?= htmlspecialchars($tabla) ?>&id=<?= htmlspecialchars($id) ?>&seccion=<?= htmlspecialchars($seccion) ?>" method="post">
			<?= generarFormulario($estructura, $registro) ?>
			<button type="submit">Actualizar</button>
		</form>
	</main>

	<footer>
		<p>&copy; 2025 TaronjaBox. Todos los derechos reservados.</p>
	</footer>
</body>

</html>
<?php
// admin/crud/create.php

session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.php");  // Redirigir al login si no está autenticado
    exit();
}

// Incluir la conexión a la base de datos y funciones
include "../config/db_connect.php";
include "../util/funciones.php";

// Verificar si se han proporcionado la tabla y la sección
if (!isset($_GET['tabla']) || !isset($_GET['seccion'])) {
    die("Error: Parámetros incompletos.");
}

$tabla = $_GET['tabla'];
$seccion = $_GET['seccion'];

// Obtener la estructura de la tabla
$estructura = obtenerEstructuraTabla($conexion, $tabla);

// Si se envía el formulario, procesar los datos
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $campos = [];
    $valores = [];

    foreach ($estructura as $columna) {
        $nombre = $columna['Field'];

        // Ignorar columnas autoincrementales y timestamps
        if ($columna['Extra'] === 'auto_increment' || ($columna['Type'] === 'timestamp' && $columna['Default'] === 'CURRENT_TIMESTAMP')) {
            continue;
        }

        if (isset($_POST[$nombre])) {
            $valor = $_POST[$nombre];

            // Escapar el valor para evitar inyecciones SQL
            $valor = $conexion->real_escape_string($valor);

            $campos[] = $nombre;
            $valores[] = "'$valor'";
        }
    }

    // Construir la consulta SQL
    $camposStr = implode(", ", $campos);
    $valoresStr = implode(", ", $valores);
    $peticion = "INSERT INTO $tabla ($camposStr) VALUES ($valoresStr)";

    // Ejecutar la consulta
    if ($conexion->query($peticion)) {
        $message = "Registro creado con éxito.";
    } else {
        $message = "Error al crear el registro: " . $conexion->error;
    }

    // Redirigir a la sección correcta con un mensaje
    header("Location: ../../admin/$seccion/index.php?message=" . urlencode($message));
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Registro</title>
    <link rel="stylesheet" href="../css/style.css"> <!-- Estilos generales -->
</head>

<body>
    <header>
        <nav>
            <ul>
                <li><a href="../../dashboard.php">Inicio</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h2>Crear Nuevo Registro</h2>

        <!-- Formulario dinámico -->
        <form action="create.php?tabla=<?= htmlspecialchars($tabla) ?>&seccion=<?= htmlspecialchars($seccion) ?>" method="post">
            <?= generarFormulario($estructura) ?>
            <button type="submit">Crear</button>
        </form>
    </main>

    <footer>
        <p>&copy; 2025 TaronjaBox. Todos los derechos reservados.</p>
    </footer>
</body>

</html>
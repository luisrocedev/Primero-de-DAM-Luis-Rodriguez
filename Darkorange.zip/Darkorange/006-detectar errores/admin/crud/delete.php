<?php
// admin/crud/delete.php

session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.php");  // Redirigir al login si no está autenticado
    exit();
}

// Incluir la conexión a la base de datos
include "../config/db_connect.php";

// Verificar si se han proporcionado la tabla, el ID y la sección
if (!isset($_GET['tabla'], $_GET['id'], $_GET['seccion'])) {
    die("Error: Parámetros incompletos.");
}

$tabla = $_GET['tabla'];
$id = $_GET['id'];
$seccion = $_GET['seccion'];

// Construir la consulta SQL
$peticion = $conexion->prepare("DELETE FROM $tabla WHERE id = ?");

if (!$peticion) {
    die("Error en la preparación de la consulta: " . $conexion->error);
}

// Vincular el parámetro
$peticion->bind_param("i", $id); // "i" indica que el parámetro es un entero

// Ejecutar la consulta
if ($peticion->execute()) {
    $message = "Registro eliminado con éxito.";
} else {
    $message = "Error al eliminar el registro: " . $peticion->error;
}

// Cerrar la consulta
$peticion->close();

// Redirigir a la sección correcta con un mensaje
header("Location: ../../admin/$seccion/index.php?message=" . urlencode($message));
exit();

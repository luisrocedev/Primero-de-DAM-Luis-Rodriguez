<?php
// admin/blog/index.php

session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.php");  // Redirigir al login si no está autenticado
    exit();
}

// Incluir la conexión a la base de datos
include "../config/db_connect.php";

// Definir la tabla y la sección actual
$tabla = "blog_posts"; // Nombre de la tabla en la base de datos
$seccion = "blog"; // Sección actual para redireccionar después de las operaciones CRUD

// Mensaje de confirmación o error
$message = "";
if (isset($_GET['message'])) {
    $message = htmlspecialchars($_GET['message']);
}

// Obtener todos los registros de la tabla
$peticion = $conexion->query("SELECT * FROM $tabla");
$registros = [];

if ($peticion) {
    while ($fila = $peticion->fetch_assoc()) {
        $registros[] = $fila;
    }
} else {
    die("Error al obtener los registros: " . $conexion->error);
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión del Blog</title>
    <link rel="stylesheet" href="../css/style.css"> <!-- Estilos generales -->
</head>

<body>
    <header>
        <nav>
            <ul>
                <li><a href="../../dashboard.php">Inicio</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h2>Gestión del Blog</h2>

        <!-- Mensaje de confirmación o error -->
        <?php if (!empty($message)) : ?>
            <p class="message"><?= $message ?></p>
        <?php endif; ?>

        <!-- Enlace para crear una nueva entrada -->
        <a href="../crud/create.php?tabla=<?= htmlspecialchars($tabla) ?>&seccion=<?= htmlspecialchars($seccion) ?>">Crear Nueva Entrada</a>
        <br><br>

        <!-- Lista de entradas del blog -->
        <h3>Entradas del Blog</h3>
        <?php if (!empty($registros)) : ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Título</th>
                        <th>Contenido</th>
                        <th>Fecha de Creación</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($registros as $registro) : ?>
                        <tr>
                            <td><?= htmlspecialchars($registro['id']) ?></td>
                            <td><?= htmlspecialchars($registro['title']) ?></td>
                            <td><?= htmlspecialchars($registro['content']) ?></td>
                            <td><?= htmlspecialchars($registro['created_at']) ?></td>
                            <td>
                                <a href="../crud/update.php?tabla=<?= htmlspecialchars($tabla) ?>&id=<?= $registro['id'] ?>&seccion=<?= htmlspecialchars($seccion) ?>">Editar</a>
                                <a href="../crud/delete.php?tabla=<?= htmlspecialchars($tabla) ?>&id=<?= $registro['id'] ?>&seccion=<?= htmlspecialchars($seccion) ?>" onclick="return confirm('¿Estás seguro de eliminar esta entrada?');">Eliminar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else : ?>
            <p>No hay entradas en el blog.</p>
        <?php endif; ?>
    </main>

    <footer>
        <p>&copy; 2025 TaronjaBox. Todos los derechos reservados.</p>
    </footer>
</body>

</html>
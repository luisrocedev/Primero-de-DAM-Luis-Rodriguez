<?php
// config.php

// Definir la ruta base del proyecto
define('BASE_URL', '/GitHub/Primero-de-DAM-Luis-Rodriguez/darkorange/013-Corregir header/');

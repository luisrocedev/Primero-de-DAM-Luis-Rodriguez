<?php

/**
 * Cierra la sesión del usuario
 *
 * Este archivo destruye la sesión actual del usuario y lo redirige a la página de inicio de sesión.
 * @author [Luis Rodriguez]
 * @version 1.0
 * @since 2023-11-20
 */
session_start();
session_unset();
session_destroy();
header("Location: login.php");
exit();

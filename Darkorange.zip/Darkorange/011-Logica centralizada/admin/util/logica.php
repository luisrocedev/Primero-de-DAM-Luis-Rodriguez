<?php
// admin/util/logica.php

/**
 * Carga la lógica común para todas las secciones.
 *
 * @param string $tabla Nombre de la tabla en la base de datos.
 * @param string $seccion Nombre de la sección actual.
 * @return array Retorna un array con las variables necesarias.
 */
function cargarLogica($tabla, $seccion)
{
    // Iniciar sesión
    session_start();
    if (!isset($_SESSION['user_id'])) {
        header("Location: ../../login.php");
        exit();
    }

    // Incluir la conexión a la base de datos
    include __DIR__ . "/../config/db_connect.php";

    // Mensaje de confirmación o error
    $message = "";
    if (isset($_GET['message'])) {
        $message = htmlspecialchars($_GET['message']);
    }

    // Obtener los registros de la tabla
    $peticion = $conexion->query("SELECT * FROM $tabla");
    $registros = [];

    if ($peticion) {
        while ($fila = $peticion->fetch_assoc()) {
            $registros[] = $fila;
        }
    } else {
        die("Error al obtener los registros: " . $conexion->error);
    }

    // Retornar las variables necesarias
    return [
        'conexion' => $conexion,
        'tabla' => $tabla,
        'seccion' => $seccion,
        'message' => $message,
        'registros' => $registros
    ];
}

<?php
// admin/contacto/index.php

session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.php");  // Redirigir al login si no está autenticado
    exit();
}

// Incluir la conexión a la base de datos
include "../config/db_connect.php";

// Definir la tabla y la sección actual
$tabla = "contacto"; // Nombre de la tabla en la base de datos
$seccion = "contacto"; // Sección actual para redireccionar después de las operaciones CRUD

// Mensaje de confirmación o error
$message = "";
if (isset($_GET['message'])) {
    $message = htmlspecialchars($_GET['message']);
}

// Obtener todos los registros de la tabla
$peticion = $conexion->query("SELECT * FROM $tabla");
$registros = [];

if ($peticion) {
    while ($fila = $peticion->fetch_assoc()) {
        $registros[] = $fila;
    }
} else {
    die("Error al obtener los registros: " . $conexion->error);
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Contacto</title>
    <link rel="stylesheet" href="../css/style.css"> <!-- Estilos generales -->
</head>

<body>
    <header>
        <nav>
            <ul>
                <li><a href="../../dashboard.php">Inicio</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h2>Gestión de Mensajes de Contacto</h2>

        <!-- Mensaje de confirmación o error -->
        <?php if (!empty($message)) : ?>
            <p class="message"><?= $message ?></p>
        <?php endif; ?>

        <!-- Lista de mensajes de contacto -->
        <h3>Mensajes Recibidos</h3>
        <?php if (!empty($registros)) : ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Email</th>
                        <th>Mensaje</th>
                        <th>Fecha de Envío</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($registros as $registro) : ?>
                        <tr>
                            <td><?= htmlspecialchars($registro['id']) ?></td>
                            <td><?= htmlspecialchars($registro['nombre']) ?></td>
                            <td><?= htmlspecialchars($registro['email']) ?></td>
                            <td><?= htmlspecialchars($registro['mensaje']) ?></td>
                            <td><?= htmlspecialchars($registro['fecha_envio']) ?></td>
                            <td>
                                <a href="../crud/delete.php?tabla=<?= htmlspecialchars($tabla) ?>&id=<?= $registro['id'] ?>&seccion=<?= htmlspecialchars($seccion) ?>" onclick="return confirm('¿Estás seguro de eliminar este mensaje?');">Eliminar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else : ?>
            <p>No hay mensajes de contacto registrados.</p>
        <?php endif; ?>
    </main>

    <footer>
        <p>&copy; 2025 TaronjaBox. Todos los derechos reservados.</p>
    </footer>
</body>

</html>
<?php
session_start();  // Inicia la sesión para acceder a las variables de sesión
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");  // Si no está autenticado, redirigir al login
    exit();  // Detiene la ejecución para asegurar que no se cargue el resto del código
}
include "admin/header/header.php"
?>
<link rel="stylesheet" href="admin/css/dashboard.css"> <!-- Asegúrate de que la ruta sea correcta -->
<main class="main-content">
    <h1>Bienvenido al Panel de Administración, <?php echo $_SESSION['username']; ?></h1> <!-- Muestra el nombre del usuario -->
    <p>En este panel puedes gestionar las entradas del blog y otros contenidos.</p> <!-- Descripción general del panel -->
    <a href="logout.php">Cerrar sesión</a> <!-- Enlace para cerrar sesión -->
</main>

<footer>
    <p>&copy; 2025 TaronjaBox. Todos los derechos reservados.</p> <!-- Pie de página con derechos reservados -->
</footer>
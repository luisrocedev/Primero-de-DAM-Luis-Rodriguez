<?php
// admin/blog/index.php

session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.php");  // Redirigir al login si no está autenticado
    exit();
}

// Incluir la conexión a la base de datos
include "../config/db_connect.php";


// Definir la tabla y la sección actual
$tabla = "blog_posts"; // Nombre de la tabla en la base de datos
$seccion = "blog"; // Sección actual para redireccionar después de las operaciones CRUD

// Mensaje de confirmación o error
$message = "";
if (isset($_GET['message'])) {
    $message = htmlspecialchars($_GET['message']);
}

// Obtener todos los registros de la tabla
$peticion = $conexion->query("SELECT * FROM $tabla");
$registros = [];

if ($peticion) {
    while ($fila = $peticion->fetch_assoc()) {
        $registros[] = $fila;
    }
} else {
    die("Error al obtener los registros: " . $conexion->error);
}

<?php include "logica.php"; ?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión del Blog</title>
    <link rel="stylesheet" href="../css/dashboard.css"> <!-- Estilos generales -->
</head>

<body>
    <?php include "../includes/header.php"; ?>
    <main>
        <h2>Gestión del Blog</h2>
        <?php if (!empty($message)) : ?>
            <p class="message"><?= $message ?></p>
        <?php endif; ?>
        <a href="../crud/create.php?tabla=<?= htmlspecialchars($tabla) ?>&seccion=<?= htmlspecialchars($seccion) ?>">Crear Nueva Entrada</a>
        <br><br>
        <h3>Entradas del Blog</h3>
        <?php

        include "../util/tabla_dinamica.php";
        mostrarTablaDinamica($conexion, $tabla, $seccion);
        ?>
    </main>
    <?php include "../includes/footer.php"; ?>
</body>

</html>
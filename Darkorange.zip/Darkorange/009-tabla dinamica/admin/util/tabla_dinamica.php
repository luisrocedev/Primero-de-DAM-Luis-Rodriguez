<?php
// admin/util/tabla_dinamica.php

/**
 * Muestra una tabla dinámica basada en los datos de una tabla de la base de datos.
 *
 * @param mysqli $conexion Conexión a la base de datos.
 * @param string $tabla Nombre de la tabla.
 * @param string $seccion Sección actual (para los enlaces de editar/eliminar).
 */
function mostrarTablaDinamica($conexion, $tabla, $seccion)
{
    // Obtener los registros de la tabla
    $peticion = $conexion->query("SELECT * FROM $tabla");
    $registros = [];

    if ($peticion) {
        while ($fila = $peticion->fetch_assoc()) {
            $registros[] = $fila;
        }
    } else {
        die("Error al obtener los registros: " . $conexion->error);
    }

    // Obtener los nombres de las columnas
    $columnas = [];
    if (!empty($registros)) {
        $columnas = array_keys($registros[0]);
    }

    // Mostrar la tabla
    if (!empty($registros)) : ?>
        <table>
            <thead>
                <tr>
                    <?php foreach ($columnas as $columna) : ?>
                        <th><?= ucfirst(str_replace('_', ' ', $columna)) ?></th>
                    <?php endforeach; ?>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($registros as $registro) : ?>
                    <tr>
                        <?php foreach ($columnas as $columna) : ?>
                            <td><?= htmlspecialchars($registro[$columna]) ?></td>
                        <?php endforeach; ?>
                        <td>
                            <a href="../crud/update.php?tabla=<?= htmlspecialchars($tabla) ?>&id=<?= $registro['id'] ?>&seccion=<?= htmlspecialchars($seccion) ?>">Editar</a>
                            <a href="../crud/delete.php?tabla=<?= htmlspecialchars($tabla) ?>&id=<?= $registro['id'] ?>&seccion=<?= htmlspecialchars($seccion) ?>" onclick="return confirm('¿Estás seguro de eliminar este registro?');">Eliminar</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else : ?>
        <p>No hay registros en la tabla.</p>
<?php endif;
}
?>
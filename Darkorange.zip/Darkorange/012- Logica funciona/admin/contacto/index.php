<?php
// admin/contacto/index.php

// Incluir la lógica centralizada
include "../util/logica.php";

// Cargar la lógica para la sección "contacto"
$config = cargarLogica("contacto", "contacto");
extract($config); // Convierte el array en variables ($conexion, $tabla, $seccion, $message, $registros)
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Contacto</title>
    <link rel="stylesheet" href="../css/dashboard.css"> <!-- Estilos generales -->
    <link rel="stylesheet" href="../css/contacto.css"> <!-- Estilos específicos de contacto -->
</head>

<body>
    <?php include "../includes/header.php"; ?>
    <main>
        <h2>Gestión de Contacto</h2>

        <!-- Mensaje de confirmación o error -->
        <?php if (!empty($message)) : ?>
            <p class="message"><?= $message ?></p>
        <?php endif; ?>

        <!-- Lista de mensajes de contacto -->
        <h3>Mensajes de Contacto</h3>
        <?php if (!empty($registros)) : ?>
            <table>
                <thead>
                    <tr>
                        <?php
                        // Obtener las columnas de la tabla
                        $columnas = array_keys($registros[0]);
                        foreach ($columnas as $columna) :
                        ?>
                            <th><?= ucfirst(str_replace('_', ' ', $columna)) ?></th>
                        <?php endforeach; ?>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($registros as $registro) : ?>
                        <tr>
                            <?php foreach ($columnas as $columna) : ?>
                                <td><?= htmlspecialchars($registro[$columna]) ?></td>
                            <?php endforeach; ?>
                            <td>
                                <!-- Enlace para eliminar -->
                                <a href="../crud/delete.php?tabla=<?= htmlspecialchars($tabla) ?>&id=<?= $registro['id'] ?>&seccion=<?= htmlspecialchars($seccion) ?>" onclick="return confirm('¿Estás seguro de eliminar este mensaje?');">Eliminar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else : ?>
            <p>No hay mensajes de contacto.</p>
        <?php endif; ?>
    </main>
    <?php include "../includes/footer.php"; ?>
</body>

</html>
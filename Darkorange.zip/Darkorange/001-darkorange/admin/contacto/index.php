<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");  // Si no está autenticado, redirigir al login
    exit();
}
?>

<link rel="stylesheet" href="../css/header.css"> <!-- Incluir los estilos del panel de administración -->
<link rel="stylesheet" href="../css/style.css"> <!-- Incluir los estilos generales -->

<header>
    <nav>
        <ul>
            <li><a href="../../dashboard.php">Inicio</a></li>
            <li><a href="read.php">Ver Mensajes</a></li> <!-- Enlace para ver los mensajes -->
        </ul>
    </nav>
</header>

<main>
    <h2>Gestión de Mensajes de Contacto</h2>
    <a href="read.php">Ver Mensajes Existentes</a>
</main>

<footer>
    <p>&copy; 2025 TaronjaBox. Todos los derechos reservados.</p>
</footer>
<?php

/**
 * Página de gestión de "Precios".
 * Incluye la lógica centralizada, muestra un formulario para crear nuevos registros
 * y una tabla dinámica con los precios existentes.
 */
// admin/precios/index.php

// Incluir la lógica centralizada
include "../util/logica.php";

// Cargar la lógica para la sección "precios"
$config = cargarLogica("precios", "precios");
extract($config); // Convierte el array en variables ($conexion, $tabla, $seccion, $message, $registros)
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Precios</title>
    <link rel="stylesheet" href="../css/dashboard.css"> <!-- Estilos generales -->
</head>

<body>
    <?php include "../includes/header.php"; ?>
    <main>
        <h2>Gestión de Precios</h2>

        <!-- Mensaje de confirmación o error -->
        <?php if (!empty($message)) : ?>
            <p class="message"><?= $message ?></p>
        <?php endif; ?>

        <!-- Enlace para crear un nuevo registro -->
        <a href="../crud/create.php?tabla=<?= htmlspecialchars($tabla) ?>&seccion=<?= htmlspecialchars($seccion) ?>">Crear Nuevo Registro</a>
        <br><br>

        <!-- Lista de registros -->
        <h3>Lista de Precios</h3>
        <?php
        include "../util/tabla_dinamica.php";
        mostrarTablaDinamica($conexion, $tabla, $seccion);
        ?>
    </main>
    <?php include "../includes/footer.php"; ?>
</body>

</html>
<?php
// admin/fisioterapia/index.php

// Incluir la lógica centralizada
include "../util/logica.php";

/**
 * Cargar la lógica específica para la sección "fisioterapia".
 * La función `cargarLogica` devuelve un array con:
 * - $conexion: conexión a la base de datos.
 * - $tabla: nombre de la tabla asociada.
 * - $seccion: nombre de la sección actual.
 * - $message: mensaje de confirmación o error, si existe.
 * - $registros: array con los registros de la base de datos.
 */
$config = cargarLogica("fisioterapia", "fisioterapia");
extract($config); // Convierte el array en variables
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Fisioterapia</title>
    <link rel="stylesheet" href="../css/dashboard.css"> <!-- Estilos generales -->
</head>

<body>
    <?php include "../includes/header.php"; ?> <!-- Incluir el encabezado -->

    <main>
        <h2>Gestión de Fisioterapia</h2>

        <!-- Mostrar mensaje de confirmación o error -->
        <?php if (!empty($message)) : ?>
            <p class="message"><?= $message ?></p>
        <?php endif; ?>

        <!-- Enlace para crear un nuevo registro -->
        <a href="../crud/create.php?tabla=<?= htmlspecialchars($tabla) ?>&seccion=<?= htmlspecialchars($seccion) ?>">Crear Nuevo Registro</a>
        <br><br>

        <!-- Mostrar la lista de registros -->
        <h3>Lista de Registros</h3>
        <?php
        // Incluir el archivo con la función para mostrar tablas dinámicas
        include "../util/tabla_dinamica.php";

        // Mostrar la tabla dinámica con los registros de la base de datos
        mostrarTablaDinamica($conexion, $tabla, $seccion);
        ?>
    </main>

    <?php include "../includes/footer.php"; ?> <!-- Incluir el pie de página -->
</body>

</html>
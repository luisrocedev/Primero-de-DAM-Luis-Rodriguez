<?php

/**
 * Muestra una tabla dinámica con los registros de una tabla específica.
 * Incluye opciones para editar y eliminar registros.
 */
function mostrarTablaDinamica($conexion, $tabla, $seccion)
{
    $peticion = $conexion->query("SELECT * FROM $tabla");
    $registros = [];

    if ($peticion) {
        while ($fila = $peticion->fetch_assoc()) {
            $registros[] = $fila;
        }
    } else {
        die("Error al obtener los registros: " . $conexion->error);
    }

    $columnas = [];
    if (!empty($registros)) {
        $columnas = array_keys($registros[0]);
    }

    if (!empty($registros)) : ?>
        <table>
            <thead>
                <tr>
                    <?php foreach ($columnas as $columna) : ?>
                        <th><?= ucfirst(str_replace('_', ' ', $columna)) ?></th>
                    <?php endforeach; ?>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($registros as $registro) : ?>
                    <tr>
                        <?php foreach ($columnas as $columna) : ?>
                            <td><?= htmlspecialchars($registro[$columna]) ?></td>
                        <?php endforeach; ?>
                        <td>
                            <a href="../crud/update.php?tabla=<?= htmlspecialchars($tabla) ?>&id=<?= $registro['id'] ?>&seccion=<?= htmlspecialchars($seccion) ?>">Editar</a>
                            <a href="../crud/delete.php?tabla=<?= htmlspecialchars($tabla) ?>&id=<?= $registro['id'] ?>&seccion=<?= htmlspecialchars($seccion) ?>" onclick="return confirm('¿Estás seguro de eliminar este registro?');">Eliminar</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else : ?>
        <p>No hay registros en la tabla.</p>
<?php endif;
}
?>
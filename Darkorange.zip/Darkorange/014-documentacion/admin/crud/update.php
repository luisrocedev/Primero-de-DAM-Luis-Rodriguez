<?php
// admin/crud/update.php

session_start();

/**
 * Verificar si el usuario está autenticado.
 * Si no lo está, redirigir al login.
 */
if (!isset($_SESSION['user_id'])) {
	header("Location: ../../login.php");  // Redirigir al login si no está autenticado
	exit();
}

// Incluir la conexión a la base de datos y las funciones necesarias
include "../config/db_connect.php";
include "../util/funciones.php";

/**
 * Verificar si se han proporcionado los parámetros necesarios:
 * - tabla: nombre de la tabla.
 * - id: identificador del registro a editar.
 * - seccion: sección actual.
 */
if (!isset($_GET['tabla'], $_GET['id'], $_GET['seccion'])) {
	die("Error: Parámetros incompletos.");
}

$tabla = $_GET['tabla'];       // Nombre de la tabla
$id = $_GET['id'];             // ID del registro
$seccion = $_GET['seccion'];   // Sección actual

// Obtener la estructura de la tabla (columnas y propiedades)
$estructura = obtenerEstructuraTabla($conexion, $tabla);

// Obtener el registro actual a editar
$peticion = $conexion->prepare("SELECT * FROM $tabla WHERE id = ?");
if (!$peticion) {
	die("Error en la preparación de la consulta: " . $conexion->error);
}

$peticion->bind_param("i", $id); // "i" indica que el parámetro es un entero
$peticion->execute();
$resultado = $peticion->get_result();
$registro = $resultado->fetch_assoc();

if (!$registro) {
	die("Error: Registro no encontrado."); // Verificar si el registro existe
}

/**
 * Procesar el formulario al enviarse.
 * Actualizar el registro en la tabla con los nuevos datos.
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$actualizaciones = []; // Almacena las columnas y sus nuevos valores

	foreach ($estructura as $columna) {
		$nombre = $columna['Field'];

		// Ignorar columnas autoincrementales y de marca de tiempo
		if ($columna['Extra'] === 'auto_increment' || ($columna['Type'] === 'timestamp' && $columna['Default'] === 'CURRENT_TIMESTAMP')) {
			continue;
		}

		// Procesar los campos enviados en el formulario
		if (isset($_POST[$nombre])) {
			$valor = $_POST[$nombre];
			$actualizaciones[] = "$nombre = '" . $conexion->real_escape_string($valor) . "'";
		}
	}

	// Construir la consulta SQL para actualizar el registro
	$actualizacionesStr = implode(", ", $actualizaciones);
	$peticion = "UPDATE $tabla SET $actualizacionesStr WHERE id = $id";

	// Ejecutar la consulta
	if ($conexion->query($peticion)) {
		$message = "Registro actualizado con éxito."; // Mensaje de éxito
	} else {
		$message = "Error al actualizar el registro: " . $conexion->error; // Mensaje de error
	}

	// Redirigir a la sección correspondiente con un mensaje
	header("Location: ../../admin/$seccion/index.php?message=" . urlencode($message));
	exit();
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Editar Registro</title>
	<link rel="stylesheet" href="../css/style.css"> <!-- Estilos generales -->
</head>

<body>
	<header>
		<nav>
			<ul>
				<li><a href="../../dashboard.php">Inicio</a></li> <!-- Enlace al panel principal -->
			</ul>
		</nav>
	</header>

	<main>
		<h2>Editar Registro</h2>

		<!-- Formulario dinámico -->
		<form action="update.php?tabla=<?= htmlspecialchars($tabla) ?>&id=<?= htmlspecialchars($id) ?>&seccion=<?= htmlspecialchars($seccion) ?>" method="post">
			<?= generarFormulario($estructura, $registro) ?> <!-- Generar los campos del formulario dinámicamente -->
			<button type="submit">Actualizar</button> <!-- Botón para enviar el formulario -->
		</form>
	</main>

	<footer>
		<p>&copy; 2025 TaronjaBox. Todos los derechos reservados.</p>
	</footer>
</body>

</html>
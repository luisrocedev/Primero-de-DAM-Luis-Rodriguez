<?php
session_start();

/**
 * Verificar si el usuario está autenticado.
 * Si no lo está, redirigir al login.
 */
if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.php");  // Redirigir al login si no está autenticado
    exit();
}

// Incluir la conexión a la base de datos y funciones necesarias
include "../config/db_connect.php";
include "../util/funciones.php";

/**
 * Verificar si se han proporcionado los parámetros necesarios
 * (la tabla y la sección).
 */
if (!isset($_GET['tabla']) || !isset($_GET['seccion'])) {
    die("Error: Parámetros incompletos.");
}

$tabla = $_GET['tabla'];       // Nombre de la tabla
$seccion = $_GET['seccion'];   // Sección a la que pertenece

// Obtener la estructura de la tabla desde la base de datos
$estructura = obtenerEstructuraTabla($conexion, $tabla);

/**
 * Procesar el formulario al enviarse.
 * Insertar un nuevo registro en la tabla indicada.
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $campos = [];  // Almacena los nombres de las columnas
    $valores = []; // Almacena los valores a insertar

    // Recorrer la estructura de la tabla
    foreach ($estructura as $columna) {
        $nombre = $columna['Field']; // Nombre de la columna

        // Ignorar columnas autoincrementales y de marca de tiempo
        if ($columna['Extra'] === 'auto_increment' || ($columna['Type'] === 'timestamp' && $columna['Default'] === 'CURRENT_TIMESTAMP')) {
            continue;
        }

        // Si el campo está en el formulario, procesarlo
        if (isset($_POST[$nombre])) {
            $valor = $_POST[$nombre];

            // Escapar el valor para prevenir inyecciones SQL
            $valor = $conexion->real_escape_string($valor);

            $campos[] = $nombre;       // Agregar el nombre de la columna
            $valores[] = "'$valor'";  // Agregar el valor entre comillas
        }
    }

    // Construir la consulta SQL para insertar el registro
    $camposStr = implode(", ", $campos);      // Nombres de las columnas
    $valoresStr = implode(", ", $valores);   // Valores a insertar
    $peticion = "INSERT INTO $tabla ($camposStr) VALUES ($valoresStr)";

    // Ejecutar la consulta y verificar el resultado
    if ($conexion->query($peticion)) {
        $message = "Registro creado con éxito."; // Mensaje de éxito
    } else {
        $message = "Error al crear el registro: " . $conexion->error; // Mensaje de error
    }

    // Redirigir a la sección correspondiente con el mensaje
    header("Location: ../../admin/$seccion/index.php?message=" . urlencode($message));
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Registro</title>
    <link rel="stylesheet" href="../css/style.css"> <!-- Estilos generales -->
</head>

<body>
    <header>
        <nav>
            <ul>
                <li><a href="../../dashboard.php">Inicio</a></li> <!-- Enlace al panel principal -->
            </ul>
        </nav>
    </header>

    <main>
        <h2>Crear Nuevo Registro</h2>

        <!-- Formulario dinámico -->
        <form action="create.php?tabla=<?= htmlspecialchars($tabla) ?>&seccion=<?= htmlspecialchars($seccion) ?>" method="post">
            <?= generarFormulario($estructura) ?> <!-- Generar los campos del formulario dinámicamente -->
            <button type="submit">Crear</button> <!-- Botón para enviar el formulario -->
        </form>
    </main>

    <footer>
        <p>&copy; 2025 TaronjaBox. Todos los derechos reservados.</p>
    </footer>
</body>

</html>
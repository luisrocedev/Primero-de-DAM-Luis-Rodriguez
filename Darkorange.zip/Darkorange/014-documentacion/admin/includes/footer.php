<?php

/**
 * Pie de página con derechos de autor.
 * Muestra el mensaje: "© 2025 TaronjaBox. Todos los derechos reservados."
 */
?>
<footer>
    <p>&copy; 2025 TaronjaBox. Todos los derechos reservados.</p>
</footer>
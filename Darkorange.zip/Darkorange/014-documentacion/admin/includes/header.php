<?php

/**
 * Encabezado de la página con menú de navegación.
 * Incluye enlaces a las secciones principales del sitio usando la constante BASE_URL.
 */
// Incluir el archivo de configuración
include __DIR__ . '/../../config.php';
?>
<header>
    <nav>
        <ul>
            <!-- Enlaces de navegación usando BASE_URL -->
            <li><a href="<?= BASE_URL ?>dashboard.php">Inicio</a></li>
            <li><a href="<?= BASE_URL ?>admin/quienes_somos/index.php">Quienes somos</a></li>
            <li><a href="<?= BASE_URL ?>admin/nuestro_equipo/index.php">Nuestro equipo</a></li>
            <li><a href="<?= BASE_URL ?>admin/blog/index.php">Blog</a></li>
            <li><a href="<?= BASE_URL ?>admin/fisioterapia/index.php">Fisioterapia</a></li>
            <li><a href="<?= BASE_URL ?>admin/precios/index.php">Precios</a></li>
            <li><a href="<?= BASE_URL ?>admin/contacto/index.php">Contacto</a></li>
        </ul>
    </nav>
</header>
<?php

/**
 * Conexión a la base de datos.
 * 
 * Establece la conexión con la base de datos MySQL y maneja errores de conexión.
 */

// Parámetros de conexión
$servername = "localhost";  // Servidor de la base de datos
$username = "taronjaboxvalencia";  // Usuario de la base de datos
$password = "taronjaboxvalencia";  // Contraseña de la base de datos
$database = "taronjaboxvalencia";  // Nombre de la base de datos

// Crear conexión
$conexion = new mysqli($servername, $username, $password, $database);

// Verificar conexión
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);  // Detener si hay error
}

<?php

/**
 * Configuración básica del proyecto.
 * 
 * Define la ruta base del proyecto para facilitar el manejo de rutas relativas.
 */

// Definir la ruta base del proyecto
define('BASE_URL', '/GitHub/Primero-de-DAM-Luis-Rodriguez/darkorange/014-documentacion/');

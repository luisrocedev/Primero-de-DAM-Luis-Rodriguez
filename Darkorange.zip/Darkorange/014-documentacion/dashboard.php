<?php

/**
 * Panel de administración.
 * 
 * Verifica si el usuario está autenticado y muestra el panel de administración.
 */

session_start();  // Iniciar la sesión para acceder a las variables de sesión

// Verificar si el usuario está autenticado
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");  // Redirigir al login si no está autenticado
    exit();  // Detener la ejecución
}

include "admin/includes/header.php";  // Incluir el encabezado del panel
?>

<!-- Enlazar el archivo de estilos del panel -->
<link rel="stylesheet" href="admin/css/dashboard.css">

<main class="main-content">
    <h1>Bienvenido al Panel de Administración, <?php echo $_SESSION['username']; ?></h1> <!-- Mostrar nombre de usuario -->
    <p>En este panel puedes gestionar las entradas del blog y otros contenidos.</p> <!-- Descripción del panel -->

    <!-- Botón para crear una nueva sección -->
    <a href="logout.php">Cerrar sesión</a> <!-- Enlace para cerrar sesión -->
</main>

<footer>
    <p>&copy; 2025 TaronjaBox. Todos los derechos reservados.</p> <!-- Pie de página -->
</footer>
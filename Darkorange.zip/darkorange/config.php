<?php

/**
 * Configuración básica del proyecto.
 * 
 * Define la ruta base del proyecto para facilitar el manejo de rutas relativas.
 */

// Definir la ruta base del proyecto
define('BASE_URL', '/darkorange/');
